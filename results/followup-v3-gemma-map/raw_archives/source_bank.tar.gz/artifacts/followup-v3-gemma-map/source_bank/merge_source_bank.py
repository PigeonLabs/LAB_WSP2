from pathlib import Path
import json,hashlib,collections,datetime
root=Path('reports/v3')
paths=[root/'source_met_draft.json',root/'source_ownership_draft.json',root/'source_temporal_draft.json']
records=[]
for p in paths:
 for original in json.loads(p.read_text())['records']:
  r=dict(original); r['component_artifact']=str(p)
  r['license']=r.get('license',r.get('source_license'))
  r['controlled_paraphrase']=r.get('controlled_paraphrase',r.get('short_controlled_paraphrase',r.get('controlled_paraphrases')))
  r['source_document_lineage']=r.get('source_document_lineage','wikidata-item/'+r['source_record_id'])
  r['underlying_entity_or_event']=r.get('underlying_entity_or_event',r.get('underlying_event_id',r.get('source_event_group')))
  r['renderer_family']=r.get('renderer_family',r.get('rendering_lineage_id','new-record-scoped-ownership-v1'))
  r['retrieved_utc']=r.get('retrieved_utc',r.get('retrieved_at_utc',r.get('retrieved_date')))
  r['R_assignment']=None
  r['normalized_canonical_facts_sha256']=hashlib.sha256(json.dumps(r['canonical_facts'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
  records.append(r)
counts=dict(collections.Counter(x['concept'] for x in records))
assert counts==dict(negation=16,numeric_comparison=16,ownership_coreference=16,temporal_order=16),counts
assert len(set(r['record_id'] for r in records))==64
assert len(set(r['source_url'] for r in records))==64
for r in records:
 assert r['canonical_facts'] and all(r['controlled_paraphrase'].get(k) for k in ('en','ko'))
 assert 'CC0' in r['license'] and r['license_url'].startswith('https://')
 if r.get('raw_snapshot'):
  assert hashlib.sha256(Path(r['raw_snapshot']).read_bytes()).hexdigest()==r['raw_snapshot_sha256']
# Check source identity crosswalks, rather than assuming different providers imply different entities.
external=[r.get('external_entity_id') or (r['source_record_id'] if r['source_url'].startswith('https://www.wikidata.org/') else None) for r in records]
qids=[x for x in external if x]
assert len(set(qids))==len(qids)
obj=dict(schema='v3-real-source-fact-bank-2',status='64_REAL_SOURCE_RECORDS_COLLECTED_NOT_R_MATERIALIZED',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),record_count=64,counts_by_concept=counts,canonical_fact_count=sum(len(r['canonical_facts']) for r in records),distinct_source_urls=64,distinct_record_event_groups=len({r['underlying_entity_or_event'] for r in records}),candidate_rendering_lineages=sorted({r['renderer_family'] for r in records}),independence=dict(source_records='64 distinct accession/entity records, checked against available Wikidata identity crosswalks',statistical_independence='Not guaranteed; shared references, editorial production, artist/program/entity links remain dependence axes.',source_institution='Separate metadata, not automatically the source-cluster unit.',template_generalization='Four shared new renderer families, NOT64 independent templates; strict R/T source+template gate not satisfied by record count.',shared_original_document_policy='Link same original citations/document/derivation where known; different pages or QIDs do not themselves prove independence.'),components=[dict(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths],prohibited_uses=['Do not treat these64records as64 independent renderer/template lineages.','Do not infer absent property is false.','Do not treat historical owned_by assertions as verified current ownership.','Do not run or generate R before root E prompt freeze and approved renderer/oracle checks.','No T/O construction or scoring.'],limitations=['Source facts were programmatically extracted and agent-reviewed, not independently human-validated.','Numeric source sample is European art; source-scope claims are limited to catalogue measurements.','Negation evidence consists of explicit catalogue label predicates; lexical/type shortcuts require balancing during future construction.','Temporal births/deaths have a trivial event-type ordering shortcut; this bank alone is insufficient to claim general temporal reasoning.','Famous paintings and scientists plus distinct-artist filtering are a convenience sample, not random population sampling.','New bilingual renderer/parser tests and source/family assignment remain outstanding.'],audit=dict(record_count_pass=True,balanced_concepts_pass=True,unique_record_id_and_source_url_pass=True,available_cross_provider_QID_identity_dedup_pass=True,KO_EN_nonempty_pass=True,all_CC0_structured_metadata_pass=True,met32_raw_snapshot_sha256_pass=True,placeholder_records=0,R_prompts_generated=0,T_O_generated=0),records=records)
p=root/'Rsourcecatalogv2.json';p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:obj[k] for k in ('record_count','counts_by_concept','canonical_fact_count','distinct_record_event_groups','candidate_rendering_lineages')},ensure_ascii=False)); print('sha256',hashlib.sha256(p.read_bytes()).hexdigest())
