"""CPU-only source-fact replay; never constructs or evaluates R/T/O prompts."""
import json, hashlib
from pathlib import Path

def validate(path='reports/v3/Rsourcecatalogv2.json'):
    d=json.loads(Path(path).read_text());counts={}; facts=0; cached={}
    assert len(d['records'])==64
    for r in d['records']:
        counts[r['concept']]=counts.get(r['concept'],0)+1
        p=r['raw_snapshot']
        if p not in cached:
            b=Path(p).read_bytes();cached[p]=(hashlib.sha256(b).hexdigest(),json.loads(b))
        sha,raw=cached[p];assert sha==r['raw_snapshot_sha256']
        expected=hashlib.sha256(json.dumps(r['canonical_facts'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        assert expected==r['normalized_canonical_facts_sha256']
        if r['record_id'].startswith('met-'):
            assert str(raw['objectID'])==r['record_id'].split('-')[1]
            if r['concept']=='numeric_comparison':
                overall=next(x['elementMeasurements'] for x in raw['measurements'] if x['elementName']=='Overall' and 'Height'in x['elementMeasurements'] and 'Width'in x['elementMeasurements'])
                assert 'cm' in raw['dimensions']
                values={'height_cm':overall['Height'],'width_cm':overall['Width']}
            else: values={'catalogue_object_type':raw['objectName'],'catalogue_title':raw['title']}
            for f in r['canonical_facts']:assert f['value']==values[f['predicate']]
        else:
            entity=raw['entities'][r['source_record_id']]
            assert entity['lastrevid']==r['source_revision']
            for f in r['canonical_facts']:
                prop=f['predicate'].split('/')[0]
                matches=[s for s in entity['claims'][prop] if s['id']==f['statement_id']]
                assert len(matches)==1
                statement=matches[0]
                assert statement['rank']==f['rank'] and statement['rank']!='deprecated'
                value=statement['mainsnak']['datavalue']['value']
                if prop=='P127':
                    assert value['id']==f['object']
                    assert statement==r['evidence']['statement']
                else:
                    assert value==f['object']
                    assert value['precision']==11 and value['calendarmodel'].endswith('/Q1985727')
                    assert [x['hash'] for x in statement.get('references',[])]==[x['hash'] for x in f['references']]
        assert r['R_assignment'] is None
        assert all(r['controlled_paraphrase'].get(k) for k in ['en','ko'])
        facts+=len(r['canonical_facts'])
    assert set(counts.values())=={16} and len(counts)==4
    return dict(status='PASS_SOURCE_FACT_REPLAY_ONLY',records=64,canonical_facts=facts,counts_by_concept=counts,raw_snapshots=len(cached),checks=['Every raw snapshot hash','Met exact selected property values','Wikidata exact recorded revision/property/statement values','Ownership full original statement including qualifiers/references','Temporal date precision/calendar and reference hashes','Canonical fact hashes','KO/EN presence, no R assignment'],limitations=['Does not independently verify truth of upstream data.','Does not certify independent source or template sampling.','Does not validate an R renderer, oracle, or capability gate.'],catalogue_sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
if __name__=='__main__':
    audit=validate()
    Path('reports/v3/SOURCE_BANK_VALIDATION.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(audit,ensure_ascii=False))
