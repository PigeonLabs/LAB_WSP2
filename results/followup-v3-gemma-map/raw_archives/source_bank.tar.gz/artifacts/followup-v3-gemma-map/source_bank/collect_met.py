import urllib.request,json,hashlib,datetime,concurrent.futures,time
from pathlib import Path
base='https://collectionapi.metmuseum.org/public/collection/v1/'
out=Path('artifacts/followup-v3-gemma-map/source_bank')
def fetch(p):
 req=urllib.request.Request(base+p,headers={'User-Agent':'WSP2ResearchSourceAudit/1.0'})
 for i in range(3):
  try:
   raw=urllib.request.urlopen(req,timeout=35).read();return json.loads(raw),raw
  except Exception:
   if i==2:return None,None
   time.sleep(1)
ids,_=fetch('objects?departmentIds=11')
ids=ids['objectIDs']
# Deterministic spread over separate accession records, before any model use.
candidates=[ids[(len(ids)-1)*i//119] for i in range(120)]
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:
 rows=list(ex.map(lambda i:fetch('objects/'+str(i)),candidates))
selected=[];artists=set()
for d,raw in rows:
 if not d or not d.get('title') or not d.get('objectName'):continue
 artist=d.get('artistDisplayName','')
 if not artist or artist in artists:continue
 measurements=[x for x in (d.get('measurements') or []) if x.get('elementName')=='Overall' and x.get('elementMeasurements',{}).get('Height',0)>0 and x.get('elementMeasurements',{}).get('Width',0)>0]
 if not measurements or 'cm' not in d.get('dimensions',''):continue
 m=measurements[0]['elementMeasurements'];h=float(m['Height']);w=float(m['Width'])
 if h==w:continue
 selected.append((d,raw,h,w));artists.add(artist)
 if len(selected)==32:break
records=[]
for j,(d,raw,h,w) in enumerate(selected):
 oid=d['objectID']; concept='numeric_comparison' if j<16 else 'negation'
 snapshot=f'met_{oid}.json';(out/snapshot).write_bytes(raw)
 if concept=='numeric_comparison':
  facts=[{'subject':f'met:{oid}:overall','predicate':'height_cm','value':h},{'subject':f'met:{oid}:overall','predicate':'width_cm','value':w}]
  en=f'For catalogue object {oid}, the overall height is {h:g} cm and the overall width is {w:g} cm.'
  ko=f'도록 객체 {oid}의 전체 높이는 {h:g} cm이고 전체 너비는 {w:g} cm이다.'
  oracle={'operation':'decimal_compare_same_object_same_element_same_dimension','fields':['height_cm','width_cm'],'unit':'cm','note':'Compare recorded dimensions, not current object measurements; image/frame/glazing measures excluded.'}
 else:
  facts=[{'subject':f'met:{oid}','predicate':'catalogue_object_type','value':d['objectName']},{'subject':f'met:{oid}','predicate':'catalogue_title','value':d['title']}]
  # Exact catalogue-label mention avoids uncertain translations of art categories.
  en=f'The catalogue assigns object {oid} the type label "{d["objectName"]}" and the title "{d["title"]}".'
  ko=f'도록은 객체 {oid}의 유형 표기를 "{d["objectName"]}", 제목 표기를 "{d["title"]}"로 제시한다.'
  oracle={'operation':'explicit_fact_polarity','predicate':'catalogue_object_type','polarity_scope':'Negate the explicitly stated exact-label predicate; no closed-world inference from missing properties.','note':'Affirmative evidence bank only. Later opposite-state fictional context must be marked hypothetical; no R pair or answer generated here.'}
 records.append(dict(record_id=f'met-{oid}',concept=concept,status='FACT_BANK_CANDIDATE_NOT_R_APPROVED',source_url=d.get('objectURL') or 'https://www.metmuseum.org/art/collection/search/'+str(oid),api_url=base+'objects/'+str(oid),source_institution='Metropolitan Museum of Art',source_record_id=d['accessionNumber'],source_creator=d['artistDisplayName'],source_document_lineage=f'met-accession:{d["accessionNumber"]}',underlying_entity_or_event=f'met-object:{oid}',derivation_parent=None,shared_dependencies=['Met collection metadata production/API schema','European Paintings department sampling frame'],independence_status='Distinct accession and artist in this 32-record sample; statistical independence not guaranteed. Institution/schema recorded as dependence axes, not forced into one source-document lineage.',license='CC0-1.0 basic collection metadata',license_url='https://www.metmuseum.org/hubs/open-access',api_license_url='https://metmuseum.github.io/',retrieved_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),raw_snapshot='artifacts/followup-v3-gemma-map/source_bank/'+snapshot,raw_snapshot_sha256=hashlib.sha256(raw).hexdigest(),source_field_paths=['measurements[elementName=Overall].elementMeasurements','dimensions'] if concept=='numeric_comparison' else ['objectName','title'],canonical_facts=facts,controlled_paraphrase={'en':en,'ko':ko},oracle_spec=oracle,renderer_family='new-catalogue-dimension-v1' if concept=='numeric_comparison' else 'new-catalogue-exact-label-polarity-v1',renderer_oracle_status='NEW_RENDERER_AND_INDEPENDENT_TEXT_PARSER_REQUIRED; not supported by four existing engineering grammars',R_assignment=None))
Path('reports/v3/source_met_draft.json').write_text(json.dumps({'status':'SOURCE_FACT_BANK_ONLY','requested':32,'actual':len(records),'sampling':'120 evenly spaced department11 catalogue records; retain first32 with unique artist, exact Overall height/width and displayed cm units; no model outputs used','records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fetched':len(rows),'eligible_selected':len(records),'numeric':sum(r['concept']=='numeric_comparison' for r in records),'negation':sum(r['concept']=='negation' for r in records),'artists':len(artists)}))
